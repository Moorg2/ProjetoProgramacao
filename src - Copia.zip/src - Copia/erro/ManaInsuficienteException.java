package erro;

public class ManaInsuficienteException extends Exception {
    public ManaInsuficienteException(String message) {
        super(message);
}
}