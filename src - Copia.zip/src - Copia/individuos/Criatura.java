package individuos;

import deck.Carta;
import ProjetoProgramacao.JogoDeCartas;

public class Criatura extends Carta {
    private int dano;
    private int resist;
    private String habilidade;

    public Criatura(String nome, int custoMana, int dano, int resist, String habilidade) {
        super(nome, custoMana);
        this.dano = dano;
        this.resist = resist;
        this.habilidade = habilidade;
    }

    public int getDano() {
        return this.dano;
    }

    public int getResist() {
        return this.resist;
    }

    public void setResist(int resist) {
        this.resist = resist;
    }

    public String getHabilidade() {
        return this.habilidade;
    }

    public void executarHabilidade(int indice) {
        switch (indice) {
            case 0 -> {
                this.dano++;
                System.out.println("Queimadura! O dano de " + getNome() + " aumentou para " + this.dano);
            }
            case 1 -> {
                this.resist--;
                System.out.println("Medo! A resistência de " + getNome() + " diminuiu para " + this.resist);
            }
            case 2 -> {
                System.out.println("Final dance!");
                if (this.resist <= 5) {
                    this.dano *= 1.2; // Aumenta o dano em 20%
                    System.out.println("O dano de " + getNome() + " aumentou para " + this.dano);
                }
            }
            default -> System.out.println("Habilidade inválida.");
        }
    }

    public void escolhaHabilidade() {
        if (habilidade == null) {
            System.out.println(getNome() + " não possui habilidades.");
            return;
        }

        switch (habilidade) {
            case "Queimadura" -> executarHabilidade(0);
            case "Medo" -> executarHabilidade(1);
            case "Final Dance" -> executarHabilidade(2);
            default -> System.out.println("Habilidade inválida.");
        }
    }

    public void ataque(Criatura outraCriatura) {
        System.out.println(getNome() + " está atacando " + outraCriatura.getNome());

        // Reduz a resistência de ambas as criaturas
        outraCriatura.setResist(outraCriatura.getResist() - this.dano);
        setResist(this.resist - outraCriatura.getDano());

        // Verifica se a criatura atacada foi destruída
        if (outraCriatura.getResist() <= 0) {
            System.out.println(outraCriatura.getNome() + " foi destruída!");
            JogoDeCartas.board.remove(outraCriatura); // Remove do tabuleiro
            Jogador.cemiterio.add(outraCriatura); // Adiciona ao cemitério
        }

        // Verifica se a criatura atacante foi destruída
        if (getResist() <= 0) {
            System.out.println(getNome() + " foi destruída!");
            JogoDeCartas.board.remove(this); // Remove do tabuleiro
            Jogador.cemiterio.add(this); // Adiciona ao cemitério
        }
    }
}